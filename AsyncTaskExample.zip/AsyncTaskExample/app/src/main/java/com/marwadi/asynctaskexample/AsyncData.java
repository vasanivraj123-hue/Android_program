package com.marwadi.asynctaskexample;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
//import android.widget.Toast;

public class AsyncData extends AsyncTask<String,Integer,String> {

    // Constructor for Context
    Context localContext;

    // AlertDialog from dialogs.
    //For toast comment this section.
    AlertDialog.Builder builder;

    public AsyncData(MainActivity globalContext) {
        localContext = globalContext;
    }

    // PreExecute starts without any requirement so for Declaration can be used.
    @Override
    protected void onPreExecute() {
        //comment this section for use toast
        builder = new AlertDialog.Builder(localContext);
    }

    // For AsyncTask
    @Override
    protected String doInBackground(String... strings) {
        //using parameters as strings
        String data = strings[0];
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        //This return methods will pass data to onPostExecute(as a string only).
        return data;
    }


    @Override
    protected void onPostExecute(String data) {
        //Printing data in AlertDialog.
        // also use toast for simple structure.
//       Toast.makeText(localContext,data , Toast.LENGTH_SHORT).show();
        builder.setMessage(data)
                .setTitle("AsyncTaskExample")
                .setCancelable(true)
                .setIcon(R.drawable.ic_launcher_background)
           .show();
    }
}
