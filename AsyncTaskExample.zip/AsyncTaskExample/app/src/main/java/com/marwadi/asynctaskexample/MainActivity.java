package com.marwadi.asynctaskexample;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(v->{
            //creating our class for asyncTask
            //Execute methods calls AsyncTask as collection framework than AsyncTask decides to pass the data to doInBackground method.
            new AsyncData(MainActivity.this).execute("This is request passed from activity one.");
        });
    }
}