package com.example.activitylife;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends Activity {

    final String TAG = "MyLog";

    @Override
    protected void onCreate(Bundle ss) {
        super.onCreate(ss);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate called successfully");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart called successfully");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume called successfully");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause called successfully");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop called successfully");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart called successfully");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy called successfully");
    }
}
