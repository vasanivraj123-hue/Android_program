package com.marwadi.fragmentexample;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    Button b_home,b_about,b_contact;
    Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_home = findViewById(R.id.btn_home);
        b_about = findViewById(R.id.btn_about);
        b_contact = findViewById(R.id.btn_Contact);

        b_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    fragment = new one();
                    FragmentManager fn = getSupportFragmentManager();
                    FragmentTransaction ft = fn.beginTransaction();
                    ft.replace(R.id.fragment1,fragment).commit();


            }
        });


        b_about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragment = new two();
                FragmentManager fn = getSupportFragmentManager();
                FragmentTransaction ft = fn.beginTransaction();
                ft.replace(R.id.fragment1,fragment).commit();


            }
        });

        b_contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragment = new three();
                FragmentManager fn = getSupportFragmentManager();
                FragmentTransaction ft = fn.beginTransaction();
                ft.replace(R.id.fragment1,fragment).commit();


            }
        });

    }
}