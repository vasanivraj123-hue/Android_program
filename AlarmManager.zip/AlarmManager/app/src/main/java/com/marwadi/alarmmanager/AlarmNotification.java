package com.marwadi.alarmmanager;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class AlarmNotification extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "Hello", Toast.LENGTH_SHORT).show();

 NotificationManager manager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
        Notification.Builder builder = new Notification.Builder(context);

        builder.setContentTitle("ApplicationTitle")
                .setContentText("ApplicationText")
             .setSmallIcon(R.drawable.ic_launcher_background)
                .setAutoCancel(true);

        manager.notify(1, builder.build());

    }
}
