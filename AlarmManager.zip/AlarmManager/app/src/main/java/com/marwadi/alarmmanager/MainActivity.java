package com.marwadi.alarmmanager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import static android.app.PendingIntent.FLAG_IMMUTABLE;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btn = findViewById(R.id.b_alarm);

        btn.setOnClickListener(v -> {
            AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
            Intent intent = new Intent(MainActivity. this, AlarmNotification.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this,
                    0,
                    intent, FLAG_IMMUTABLE);
            manager.set(AlarmManager.RTC_WAKEUP, 3000, pendingIntent);

        });



    }
}